<?php

$name = $_POST['name'];
$email = $email['name'];
$message = $message['name'];
$to = "pushkar.alex5@gmail.com"
$subject="Mail from Website"

